Please run the file "Install.cmd" as administrator:
In File Explorer, select the file "Install.cmd" and right-click on it.
Then choose "Run as Administrator" in pop-up menu to install the driver.
After the driver installation finished, restart system.